# name:translate
description: Client-side rendering, but not in a browser! Get the flag in ./flag.txt, and seeing the source will likely help.

# flag: CTF{Televersez_vos_exploits_dans_mon_nuagiciel}